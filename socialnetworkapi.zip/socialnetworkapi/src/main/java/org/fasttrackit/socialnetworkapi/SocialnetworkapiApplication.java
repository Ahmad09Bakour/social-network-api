package org.fasttrackit.socialnetworkapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SocialnetworkapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(SocialnetworkapiApplication.class, args);
	}

}
